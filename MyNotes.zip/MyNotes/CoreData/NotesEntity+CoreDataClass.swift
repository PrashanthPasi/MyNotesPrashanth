//
//  NotesEntity+CoreDataClass.swift
//  MyNotes
//
//  Created by Pace Wisdom on 23/06/20.
//  Copyright © 2020 Pace Wisdom. All rights reserved.
//
//

import Foundation
import CoreData


public class NotesEntity: NSManagedObject {

}
